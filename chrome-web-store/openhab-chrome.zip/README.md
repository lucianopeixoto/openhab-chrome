# openhab-chrome
- A simple extension that allows users to control openHAB from a popup within Chrome.
- It's now supporting HTTPS and openHAB Cloud.
- If you have sugestions, issues or code contributions, please go ahead and help the project.
- Privacy Policy: https://lucianopeixoto.github.io/openhab-chrome/privacy-policy.html
- This extension was originaly created by https://github.com/hazymat/ and now some other contributors are also working on it.